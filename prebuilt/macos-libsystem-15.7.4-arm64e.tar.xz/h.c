#include <stdio.h>
int main(){printf("hello from real macOS\n");return 0;}
